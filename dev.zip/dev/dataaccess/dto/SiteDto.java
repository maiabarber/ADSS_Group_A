package dataaccess.dto;

import transportation.domain.SiteType;

public class SiteDto {
    private String siteName;
    private String address;
    private String phoneNumber;
    private String contactName;
    private ShippingZoneDto shippingZone;
    private SiteType siteType;
    private BranchDto branch;

    public SiteDto(
            String siteName,
            String address,
            String contactName,
            String phoneNumber,
            ShippingZoneDto shippingZone,
            SiteType siteType,
            BranchDto branch) {
        this.siteName = siteName;
        this.address = address;
        this.contactName = contactName;
        this.phoneNumber = phoneNumber;
        this.shippingZone = shippingZone;
        this.siteType = siteType;
        this.branch = branch;
    }

    public String getSiteName() {
        return siteName;
    }

    public String getAddress() {
        return address;
    }

    public String getContactName() {
        return contactName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public ShippingZoneDto getShippingZone() {
        return shippingZone;
    }

    public SiteType getSiteType() {
        return siteType;
    }

    public BranchDto getBranch() {
        return branch;
    }
}