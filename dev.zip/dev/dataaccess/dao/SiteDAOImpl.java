package dataaccess.dao;

import dataaccess.DatabaseConnection;
import employee.domain.Branch;
import transportation.domain.ShippingZone;
import transportation.domain.Site;
import transportation.domain.SiteType;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SiteDAOImpl implements DaoInterface<Site> {

    @Override
    public void createOrUpdate(Site site) {
        String sql = """
                INSERT OR REPLACE INTO sites (
                    site_name,
                    address,
                    contact_name,
                    phone_number,
                    zone_code,
                    site_type,
                    branch_id
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """;

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {

            stmt.setString(1, site.getSiteName());
            stmt.setString(2, site.getAddress());
            stmt.setString(3, site.getContactName());
            stmt.setString(4, site.getPhoneNumber());
            stmt.setString(5, site.getShippingZone().getZoneCode());
            stmt.setString(6, site.getSiteType().name());

            if (site.getBranch() != null) {
                stmt.setInt(7, Integer.parseInt(site.getBranch().getBranchId()));
            } else {
                stmt.setNull(7, Types.INTEGER);
            }

            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Site findbyId(String id) {
        String sql = """
                SELECT s.site_name,
                       s.address,
                       s.contact_name,
                       s.phone_number,
                       s.zone_code,
                       s.site_type,
                       z.zone_name,
                       b.branch_id,
                       b.branch_name,
                       b.address AS branch_address
                FROM sites s
                JOIN shipping_zones z ON s.zone_code = z.zone_code
                LEFT JOIN branches b ON s.branch_id = b.branch_id
                WHERE s.site_id = ?
                """;

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {

            stmt.setInt(1, Integer.parseInt(id));

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToSite(rs);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public void update(Site site) {
        String sql = """
                UPDATE sites SET
                    address = ?,
                    contact_name = ?,
                    phone_number = ?,
                    zone_code = ?,
                    site_type = ?,
                    branch_id = ?
                WHERE site_name = ?
                """;

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {

            stmt.setString(1, site.getAddress());
            stmt.setString(2, site.getContactName());
            stmt.setString(3, site.getPhoneNumber());
            stmt.setString(4, site.getShippingZone().getZoneCode());
            stmt.setString(5, site.getSiteType().name());

            if (site.getBranch() != null) {
                stmt.setInt(6, Integer.parseInt(site.getBranch().getBranchId()));
            } else {
                stmt.setNull(6, Types.INTEGER);
            }

            stmt.setString(7, site.getSiteName());
            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(String id) {
        String sql = "DELETE FROM sites WHERE site_id = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {

            stmt.setInt(1, Integer.parseInt(id));
            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Site> findAll() {
        String sql = """
                SELECT s.site_name,
                       s.address,
                       s.contact_name,
                       s.phone_number,
                       s.zone_code,
                       s.site_type,
                       z.zone_name,
                       b.branch_id,
                       b.branch_name,
                       b.address AS branch_address
                FROM sites s
                JOIN shipping_zones z ON s.zone_code = z.zone_code
                LEFT JOIN branches b ON s.branch_id = b.branch_id
                ORDER BY s.site_id
                """;

        List<Site> sites = new ArrayList<>();

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                sites.add(mapResultSetToSite(rs));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return sites;
    }

    private Site mapResultSetToSite(ResultSet rs) throws SQLException {
        ShippingZone zone = new ShippingZone(
                rs.getString("zone_code"),
                rs.getString("zone_name")
        );

        Branch branch = null;
        String branchId = rs.getString("branch_id");

        if (branchId != null) {
            branch = new Branch(
                    branchId,
                    rs.getString("branch_name"),
                    rs.getString("branch_address")
            );
        }

        return new Site(
                rs.getString("site_name"),
                rs.getString("address"),
                rs.getString("phone_number"),
                rs.getString("contact_name"),
                zone,
                parseSiteType(rs.getString("site_type")),
                branch
        );
    }

    private SiteType parseSiteType(String rawValue) {
        if (rawValue == null || rawValue.isBlank()) {
            return SiteType.REGULAR;
        }

        try {
            return SiteType.valueOf(rawValue);
        } catch (IllegalArgumentException e) {
            return SiteType.REGULAR;
        }
    }
}